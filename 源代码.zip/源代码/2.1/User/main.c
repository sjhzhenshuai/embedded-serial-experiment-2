#include "stm32f10x.h"

/* ����ʹ�ܱ�־��1 = ���ڷ��ͣ�0 = ��ͣ���� */
volatile uint8_t send_flag = 1;

void USART1_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_USART1, ENABLE);

    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    USART_InitStructure.USART_BaudRate            = 115200;
    USART_InitStructure.USART_WordLength          = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits            = USART_StopBits_1;
    USART_InitStructure.USART_Parity              = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode                = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART1, &USART_InitStructure);

    /* ʹ�� RXNE �����жϣ�ÿ�յ�һ���ֽڴ���һ���ж� */
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);

    /* NVIC ���� */
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel                   = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    USART_Cmd(USART1, ENABLE);
}

void USART_SendByte(uint8_t ch)
{
    while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
    USART_SendData(USART1, ch);
}

void USART_SendString(char *str)
{
    while (*str)
    {
        USART_SendByte((uint8_t)*str);
        str++;
    }
}

/* USART1 �жϷ����� */
void USART1_IRQHandler(void)
{
    if (USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
    {
        uint8_t ch = USART_ReceiveData(USART1);   /* �� DR��RXNE �Զ����� */

        if (ch == '#')
        {
            send_flag = 0;      /* �յ� '#'����ͣ���� */
        }
        else if (ch == '*')
        {
            send_flag = 1;      /* �յ� '*'���ָ����� */
        }
        /* �����ַ���Ӱ�췢��״̬ */
    }
}

int main(void)
{
    USART1_Init();

    while (1)
    {
        if (send_flag)
        {
            USART_SendString("hello windows!\r\n");
            /* �ȴ����һ���ֽ������Ƴ�����֤һ֡���� */
            while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);
        }
        /* send_flag == 0 ʱѭ����ת�����ٷ����κ��ַ� */
    }
}